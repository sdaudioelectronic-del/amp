package com.ecualizador.app

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.provider.OpenableColumns
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Datos de los pads: cuántos hay, volumen, nombres y archivos propios
// ---------------------------------------------------------------------------

private val defaultNamesEs = listOf(
    "Bombo", "Caja", "Palmas", "Charles", "Tom", "Bajo",
    "Barrido", "Sirena", "Láser", "Impacto", "Campana", "Burbuja"
)
private val defaultNamesEn = listOf(
    "Kick", "Snare", "Clap", "Hi-hat", "Tom", "Sub",
    "Riser", "Siren", "Laser", "Hit", "Bell", "Bubble"
)

object PadsStore {
    const val MAX = 12
    const val MAX_BYTES = 5L * 1024 * 1024

    private var prefs: SharedPreferences? = null

    var count by mutableIntStateOf(8)
        private set

    /** Volumen de los efectos, de 0 a 100. */
    var volume by mutableIntStateOf(60)
        private set

    val names = mutableStateListOf<String>()
    val files = mutableStateListOf<String>()

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("pads_prefs", Context.MODE_PRIVATE)
        prefs = p
        count = p.getInt("count", 8).coerceIn(1, MAX)
        volume = p.getInt("volumePct", 60).coerceIn(0, 100)
        names.clear(); files.clear()
        for (i in 0 until MAX) {
            names.add(p.getString("name$i", "") ?: "")
            val path = p.getString("file$i", "") ?: ""
            files.add(if (path.isNotEmpty() && File(path).exists()) path else "")
        }
    }

    /** Volumen de 0 a 1 que se envía al reproductor. */
    fun volumeScale(): Float = Math.pow((volume / 100.0), 1.5).toFloat()

    fun changeCount(n: Int) {
        count = n.coerceIn(1, MAX)
        prefs?.edit()?.putInt("count", count)?.apply()
    }

    /** Cambia el volumen en pantalla; se guarda al soltar la barra. */
    fun changeVolume(v: Int) {
        volume = v.coerceIn(0, 100)
    }

    fun saveVolume() {
        prefs?.edit()?.putInt("volumePct", volume)?.apply()
    }

    fun setName(i: Int, value: String) {
        val clean = value.trim().take(14)
        names[i] = clean
        prefs?.edit()?.putString("name$i", clean)?.apply()
    }

    fun setFile(i: Int, path: String) {
        files[i] = path
        prefs?.edit()?.putString("file$i", path)?.apply()
    }

    fun label(i: Int): String {
        if (names[i].isNotBlank()) return names[i]
        val defaults = if (isEnglish) defaultNamesEn else defaultNamesEs
        return if (files[i].isNotEmpty()) tr("Sonido ${i + 1}", "Sound ${i + 1}") else defaults[i]
    }
}

// ---------------------------------------------------------------------------
// Reproductor: los pads NO piden el foco de audio, así que la música no se detiene
// ---------------------------------------------------------------------------

object PadPlayer {
    private val raws = intArrayOf(
        R.raw.pad_kick, R.raw.pad_snare, R.raw.pad_clap, R.raw.pad_hat,
        R.raw.pad_tom, R.raw.pad_sub, R.raw.pad_riser, R.raw.pad_siren,
        R.raw.pad_laser, R.raw.pad_hit, R.raw.pad_bell, R.raw.pad_bubble
    )

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private var pool: SoundPool? = null
    private val soundIds = IntArray(raws.size)
    private val loaded = HashSet<Int>()
    private val players = HashMap<Int, MediaPlayer>()

    fun init(context: Context) {
        if (pool != null) return
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
        for (i in raws.indices) soundIds[i] = p.load(context.applicationContext, raws[i], 1)
        pool = p
    }

    fun play(context: Context, index: Int, volume: Float) {
        init(context)
        val path = PadsStore.files.getOrElse(index) { "" }
        if (path.isEmpty()) {
            val id = soundIds.getOrElse(index) { 0 }
            if (id != 0 && loaded.contains(id)) pool?.play(id, volume, volume, 1, 0, 1f)
        } else {
            playFile(index, path, volume)
        }
    }

    /** Un archivo propio: al tocarlo otra vez mientras suena, se detiene. */
    private fun playFile(index: Int, path: String, volume: Float) {
        val current = players.remove(index)
        if (current != null) {
            val wasPlaying = runCatching { current.isPlaying }.getOrDefault(false)
            runCatching { current.release() }
            if (wasPlaying) return
        }
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(attrs)
            mp.setDataSource(path)
            mp.setVolume(volume, volume)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                runCatching { it.release() }
                if (players[index] === it) players.remove(index)
            }
            mp.setOnErrorListener { m, _, _ ->
                runCatching { m.release() }
                if (players[index] === m) players.remove(index)
                true
            }
            players[index] = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            runCatching { mp.release() }
            players.remove(index)
        }
    }

    fun stop(index: Int) {
        players.remove(index)?.let { runCatching { it.release() } }
    }

    fun stopAll() {
        players.values.forEach { runCatching { it.release() } }
        players.clear()
    }
}

// ---------------------------------------------------------------------------
// Pantalla de pads
// ---------------------------------------------------------------------------

private class ImportResult(val path: String?, val label: String, val problem: String?)

private suspend fun importSound(context: Context, index: Int, uri: Uri): ImportResult =
    withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var display = ""
            var size = -1L
            resolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (n >= 0) display = c.getString(n) ?: ""
                    val s = c.getColumnIndex(OpenableColumns.SIZE)
                    if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                }
            }
            if (size > PadsStore.MAX_BYTES) return@runCatching ImportResult(null, "", "big")

            val dir = File(context.filesDir, "pads").apply { mkdirs() }
            val known = setOf("mp3", "wav", "ogg", "m4a", "aac", "flac", "opus")
            val ext = display.substringAfterLast('.', "").lowercase().takeIf { it in known } ?: "audio"
            val target = File(dir, "pad_${index}_${System.currentTimeMillis()}.$ext")

            var copied = 0L
            var tooBig = false
            val input = resolver.openInputStream(uri) ?: return@runCatching ImportResult(null, "", "error")
            input.use { src ->
                target.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val read = src.read(buf)
                        if (read < 0) break
                        copied += read
                        if (copied > PadsStore.MAX_BYTES) { tooBig = true; break }
                        out.write(buf, 0, read)
                    }
                }
            }
            if (tooBig || copied == 0L) {
                target.delete()
                return@runCatching ImportResult(null, "", if (tooBig) "big" else "error")
            }
            ImportResult(target.absolutePath, display.substringBeforeLast('.').take(14), null)
        }.getOrElse { ImportResult(null, "", "error") }
    }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PadsDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalEqColors.current
    val scope = rememberCoroutineScope()
    var optionsFor by remember { mutableIntStateOf(-1) }
    var pickFor by remember { mutableIntStateOf(-1) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val i = pickFor
        if (uri != null && i >= 0) {
            scope.launch {
                val r = importSound(context, i, uri)
                if (r.path != null) {
                    val old = PadsStore.files[i]
                    PadPlayer.stop(i)
                    PadsStore.setFile(i, r.path)
                    if (PadsStore.names[i].isBlank()) PadsStore.setName(i, r.label)
                    if (old.isNotEmpty()) File(old).delete()
                } else {
                    val msg = if (r.problem == "big") {
                        tr("El archivo pesa más de 5 MB.", "The file is larger than 5 MB.")
                    } else {
                        tr("No se pudo usar ese archivo.", "That file could not be used.")
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = { PadPlayer.stopAll(); onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = colors.bg) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(EqSpace.lg),
                verticalArrangement = Arrangement.spacedBy(EqSpace.md)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Pads", style = EqType.lg, color = colors.text)
                    TextButton(onClick = { PadPlayer.stopAll(); onClose() }) {
                        Text(tr("Cerrar", "Close"))
                    }
                }

                EqCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(tr("Botones", "Buttons"), style = EqType.sm, color = colors.text)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { PadsStore.changeCount(PadsStore.count - 1) },
                                enabled = PadsStore.count > 1,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .size(48.dp)
                                    .semantics { contentDescription = tr("Menos botones", "Fewer buttons") }
                            ) { Text("−", style = EqType.lg) }
                            Text(
                                text = "${PadsStore.count}",
                                style = EqType.lg,
                                color = colors.text,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = EqSpace.md)
                            )
                            OutlinedButton(
                                onClick = { PadsStore.changeCount(PadsStore.count + 1) },
                                enabled = PadsStore.count < PadsStore.MAX,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .size(48.dp)
                                    .semantics { contentDescription = tr("Más botones", "More buttons") }
                            ) { Text("+", style = EqType.lg) }
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = EqSpace.md),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr("Volumen de los efectos", "Effects volume"),
                            style = EqType.sm,
                            color = colors.text
                        )
                        Text(text = "${PadsStore.volume}%", style = EqType.xs, color = colors.textMuted)
                    }
                    Slider(
                        value = PadsStore.volume.toFloat(),
                        onValueChange = { PadsStore.changeVolume(it.roundToInt()) },
                        onValueChangeFinished = { PadsStore.saveVolume() },
                        valueRange = 0f..100f,
                        modifier = Modifier.semantics {
                            contentDescription = tr("Volumen de los efectos", "Effects volume")
                        }
                    )
                }

                val columns = if (PadsStore.count <= 4) 2 else if (PadsStore.count <= 9) 3 else 4
                val indices = (0 until PadsStore.count).toList()
                Column(verticalArrangement = Arrangement.spacedBy(EqSpace.sm)) {
                    indices.chunked(columns).forEach { rowItems ->
                        Row(horizontalArrangement = Arrangement.spacedBy(EqSpace.sm)) {
                            rowItems.forEach { i ->
                                PadButton(
                                    index = i,
                                    modifier = Modifier.weight(1f),
                                    onLongPress = { optionsFor = i }
                                )
                            }
                            // Relleno para que el último botón no se estire
                            repeat(columns - rowItems.size) { Box(modifier = Modifier.weight(1f)) }
                        }
                    }
                }

                Text(
                    text = tr(
                        "Toca un botón para oír su efecto. Mantén pulsado para cambiar su sonido o su nombre. La música que está sonando no se detiene.",
                        "Tap a button to hear its effect. Press and hold to change its sound or name. Music that is playing keeps going."
                    ),
                    style = EqType.xs,
                    color = colors.textMuted
                )
            }
        }
    }

    if (optionsFor >= 0) {
        PadOptionsDialog(
            index = optionsFor,
            onPickSound = {
                pickFor = optionsFor
                optionsFor = -1
                picker.launch(arrayOf("audio/*"))
            },
            onClose = { optionsFor = -1 }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PadButton(index: Int, modifier: Modifier, onLongPress: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val colors = LocalEqColors.current
    var lit by remember { mutableStateOf(false) }
    LaunchedEffect(lit) {
        if (lit) {
            delay(140)
            lit = false
        }
    }
    val shape = RoundedCornerShape(16.dp)
    val label = PadsStore.label(index)
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(shape)
            .background(if (lit) colors.accent else colors.surface)
            .border(2.dp, colors.accent, shape)
            .combinedClickable(
                role = Role.Button,
                onClick = {
                    lit = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    PadPlayer.play(context, index, PadsStore.volumeScale())
                },
                onLongClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onLongPress()
                }
            )
            .semantics { contentDescription = tr("Pad $label", "Pad $label") }
            .padding(EqSpace.sm),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = EqType.sm,
            color = if (lit) colors.onAccent else colors.text,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun PadOptionsDialog(index: Int, onPickSound: () -> Unit, onClose: () -> Unit) {
    val colors = LocalEqColors.current
    var name by remember { mutableStateOf(PadsStore.names[index]) }
    val hasCustom = PadsStore.files[index].isNotEmpty()

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Botón ${index + 1}", "Button ${index + 1}")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(EqSpace.xs)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(14) },
                    singleLine = true,
                    label = { Text(tr("Nombre del botón", "Button name")) },
                    modifier = Modifier.fillMaxWidth()
                )
                TextButton(
                    onClick = onPickSound,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                ) { Text(tr("Elegir un sonido del teléfono", "Pick a sound from the phone")) }
                if (hasCustom) {
                    TextButton(
                        onClick = {
                            val old = PadsStore.files[index]
                            PadPlayer.stop(index)
                            PadsStore.setFile(index, "")
                            PadsStore.setName(index, "")
                            if (old.isNotEmpty()) File(old).delete()
                            onClose()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                    ) { Text(tr("Restablecer el sonido original", "Restore the original sound")) }
                }
                Text(
                    text = tr(
                        "Formatos: MP3, WAV, OGG y M4A. Máximo 5 MB.",
                        "Formats: MP3, WAV, OGG and M4A. 5 MB maximum."
                    ),
                    style = EqType.xs,
                    color = colors.textMuted
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                PadsStore.setName(index, name)
                onClose()
            }) { Text(tr("Guardar", "Save")) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text(tr("Cancelar", "Cancel")) }
        }
    )
}
