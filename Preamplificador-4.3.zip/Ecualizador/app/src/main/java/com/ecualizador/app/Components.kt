package com.ecualizador.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Ganancia en dB con signo: "+5.1", "0.0", "-0.2". Sin decimales desde 10 dB ("+12"). */
fun dbLabel(value: Float): String {
    val r = (value * 10f).roundToInt() / 10f
    val digits = if (abs(r) >= 10f) "%.0f" else "%.1f"
    return when {
        r > 0f -> "+" + String.format(digits, r)
        r < 0f -> String.format(digits, r)
        else -> "0.0"
    }
}

// ---------------------------------------------------------------------------
// Las 10 bandas: una línea fina por banda, una perilla y la curva que las une
// ---------------------------------------------------------------------------

private val GraphPad = 10.dp

private fun bandAt(x: Float, width: Float, bands: Int): Int =
    ((x / width) * bands).toInt().coerceIn(0, bands - 1)

private fun dbAt(y: Float, height: Float, pad: Float): Float {
    val usable = (height - 2f * pad).coerceAtLeast(1f)
    val ratio = ((y - pad) / usable).coerceIn(0f, 1f)
    val db = Presets.MAX_DB - ratio * (Presets.MAX_DB - Presets.MIN_DB)
    return (db * 10f).roundToInt() / 10f
}

@Composable
fun BandsGraph(
    gains: List<Float>,
    enabled: Boolean,
    onChange: (Int, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalEqColors.current
    val capStyle = LocalCapStyle.current
    val currentOnChange by rememberUpdatedState(onChange)
    val currentEnabled by rememberUpdatedState(enabled)
    var activeBand by remember { mutableIntStateOf(-1) }
    val bands = Presets.bandFreqs.size

    val summary = tr("Bandas del ecualizador. ", "Equalizer bands. ") + (0 until bands).joinToString(". ") { i ->
        tr("${Presets.bandLabels[i]} hercios, ${dbLabel(gains.getOrElse(i) { 0f })} decibelios", "${Presets.bandLabels[i]} hertz, ${dbLabel(gains.getOrElse(i) { 0f })} decibels")
    }

    Canvas(
        modifier = modifier
            .semantics { contentDescription = summary }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    if (currentEnabled) {
                        val b = bandAt(offset.x, size.width.toFloat(), bands)
                        currentOnChange(b, dbAt(offset.y, size.height.toFloat(), GraphPad.toPx()))
                    }
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        activeBand = bandAt(offset.x, size.width.toFloat(), bands)
                        if (currentEnabled) {
                            currentOnChange(
                                activeBand,
                                dbAt(offset.y, size.height.toFloat(), GraphPad.toPx())
                            )
                        }
                    },
                    onDragEnd = { activeBand = -1 },
                    onDragCancel = { activeBand = -1 }
                ) { change, _ ->
                    change.consume()
                    if (currentEnabled && activeBand >= 0) {
                        currentOnChange(
                            activeBand,
                            dbAt(change.position.y, size.height.toFloat(), GraphPad.toPx())
                        )
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val pad = GraphPad.toPx()
        val usable = h - 2f * pad
        val colW = w / bands
        val span = Presets.MAX_DB - Presets.MIN_DB
        val yFor = { db: Float -> pad + (1f - (db - Presets.MIN_DB) / span) * usable }
        val zeroY = yFor(0f)
        val xs = FloatArray(bands) { (it + 0.5f) * colW }
        val ys = FloatArray(bands) { yFor(gains.getOrElse(it) { 0f }) }
        val line = 3.dp.toPx()

        // Línea de 0 dB
        drawLine(
            color = colors.border,
            start = Offset(0f, zeroY),
            end = Offset(w, zeroY),
            strokeWidth = 1.dp.toPx()
        )
        // Pistas
        for (i in 0 until bands) {
            drawLine(
                color = colors.track,
                start = Offset(xs[i], pad),
                end = Offset(xs[i], h - pad),
                strokeWidth = line,
                cap = StrokeCap.Round
            )
        }
        // Tramo activo, desde 0 dB hasta la perilla
        if (enabled) {
            for (i in 0 until bands) {
                drawLine(
                    color = colors.accent,
                    start = Offset(xs[i], zeroY),
                    end = Offset(xs[i], ys[i]),
                    strokeWidth = line,
                    cap = StrokeCap.Round
                )
            }
        }
        // Curva suave que une las perillas
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 1 until bands) {
            val mx = (xs[i - 1] + xs[i]) / 2f
            path.cubicTo(mx, ys[i - 1], mx, ys[i], xs[i], ys[i])
        }
        drawPath(
            path = path,
            color = if (enabled) colors.accent else colors.thumb.copy(alpha = 0.45f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
        // Perillas
        for (i in 0 until bands) {
            drawBandCap(
                style = capStyle,
                cx = xs[i],
                cy = ys[i],
                held = i == activeBand,
                fill = if (enabled) colors.accent else colors.thumb,
                mark = if (enabled) colors.onAccent else colors.bg,
                ring = colors.surface
            )
        }
    }
}

/** Dibuja la tapa de una banda según el tema: fader, anillo, píldora o rombo. */
fun DrawScope.drawBandCap(
    style: CapStyle,
    cx: Float,
    cy: Float,
    held: Boolean,
    fill: Color,
    mark: Color,
    ring: Color
) {
    val k = if (held) 1.2f else 1f
    when (style) {
        CapStyle.FADER -> {
            val w = 22.dp.toPx() * k
            val h = 14.dp.toPx() * k
            val tl = Offset(cx - w / 2f, cy - h / 2f)
            drawRoundRect(color = fill, topLeft = tl, size = Size(w, h), cornerRadius = CornerRadius(4.dp.toPx()))
            drawLine(
                color = mark,
                start = Offset(tl.x + 4.dp.toPx(), cy),
                end = Offset(tl.x + w - 4.dp.toPx(), cy),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
        CapStyle.RING -> {
            val r = 8.dp.toPx() * k
            drawCircle(color = ring, radius = r, center = Offset(cx, cy))
            drawCircle(color = fill, radius = r, center = Offset(cx, cy), style = Stroke(width = 3.dp.toPx()))
        }
        CapStyle.PILL -> {
            val w = 12.dp.toPx() * k
            val h = 26.dp.toPx() * k
            drawRoundRect(
                color = fill,
                topLeft = Offset(cx - w / 2f, cy - h / 2f),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f)
            )
            drawCircle(color = mark, radius = 2.dp.toPx(), center = Offset(cx, cy))
        }
        CapStyle.DIAMOND -> {
            val r = 11.dp.toPx() * k
            val path = Path()
            path.moveTo(cx, cy - r)
            path.lineTo(cx + r, cy)
            path.lineTo(cx, cy + r)
            path.lineTo(cx - r, cy)
            path.close()
            drawPath(path = path, color = fill)
            drawCircle(color = mark, radius = 2.dp.toPx(), center = Offset(cx, cy))
        }
    }
}

// ---------------------------------------------------------------------------
// Perilla en arco (graves y loudness)
// ---------------------------------------------------------------------------

private fun pctAt(p: Offset, width: Float): Int {
    val cx = width / 2f
    val dx = p.x - cx
    val dy = cx - p.y
    var ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    if (ang < 0f) ang = if (dx < 0f) 180f else 0f
    return (((180f - ang) / 180f) * 100f).roundToInt().coerceIn(0, 100)
}

@Composable
fun ArcKnob(
    percent: Int,
    active: Boolean,
    description: String,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalEqColors.current
    val currentOnChange by rememberUpdatedState(onChange)

    Box(modifier = modifier.aspectRatio(1.8f), contentAlignment = Alignment.BottomCenter) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .semantics { contentDescription = tr("$description: $percent por ciento", "$description: $percent percent") }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        currentOnChange(pctAt(offset, size.width.toFloat()))
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        currentOnChange(pctAt(change.position, size.width.toFloat()))
                    }
                }
        ) {
            val stroke = 6.dp.toPx()
            val d = size.width - stroke
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            val arcSize = Size(d, d)
            val tint = if (active) colors.accent else colors.thumb

            drawArc(
                color = colors.track,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            val sweep = 180f * percent / 100f
            if (sweep > 0f) {
                drawArc(
                    color = tint,
                    startAngle = 180f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
            val radius = d / 2f
            val cx = size.width / 2f
            val angle = (180f + sweep) * PI.toFloat() / 180f
            drawCircle(
                color = tint,
                radius = 5.dp.toPx(),
                center = Offset(cx + radius * cos(angle), cx + radius * sin(angle))
            )
        }
        Text(
            text = "$percent%",
            style = EqType.xs,
            color = colors.textMuted,
            modifier = Modifier.padding(bottom = EqSpace.sm)
        )
    }
}

@Composable
fun EffectKnobCard(
    title: String,
    percent: Int,
    on: Boolean,
    onToggle: (Boolean) -> Unit,
    onPercent: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalEqColors.current
    EqCard(modifier = modifier, padding = EqSpace.md) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = EqType.sm,
                    color = colors.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = on,
                    onCheckedChange = onToggle,
                    modifier = Modifier.semantics { contentDescription = title }
                )
            }
            ArcKnob(
                percent = percent,
                active = on,
                description = title,
                onChange = onPercent,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 112.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Chip en forma de píldora
// ---------------------------------------------------------------------------

@Composable
fun PillChip(
    text: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val colors = LocalEqColors.current
    val shape = RoundedCornerShape(percent = 50)
    val clickable = if (onClick != null) {
        Modifier.clickable(role = Role.Button, onClick = onClick)
    } else {
        Modifier
    }
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(colors.surface)
            .border(
                width = 1.dp,
                color = if (highlight) colors.accent else colors.border,
                shape = shape
            )
            .then(clickable)
            .padding(horizontal = EqSpace.lg),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = EqType.base,
            color = colors.text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
