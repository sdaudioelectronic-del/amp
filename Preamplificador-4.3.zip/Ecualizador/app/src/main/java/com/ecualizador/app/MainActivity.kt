package com.ecualizador.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.net.Uri
import android.content.ActivityNotFoundException
import androidx.compose.material3.Button
import android.content.Intent
import android.content.ClipboardManager
import android.content.ClipData
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Size
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EqController.init(applicationContext)
        PadsStore.init(applicationContext)
        // Si el usuario lo dejó activado, se vuelve a encender el servicio.
        if (EqController.systemWide && License.isActivated(this)) EqService.start(this)
        setContent { App() }
    }
}

// ---------------------------------------------------------------------------
// Tema y pantalla principal
// ---------------------------------------------------------------------------

@Composable
fun App() {
    val dark = when (EqController.theme) {
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
        ThemeChoice.LIGHT -> false
        ThemeChoice.DARK -> true
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }
    EqTheme(dark = dark, palette = Palettes.byId(EqController.paletteId)) {
        Surface(modifier = Modifier.fillMaxSize(), color = LocalEqColors.current.bg) {
            // Pantalla de inicio: solo la primera vez que se abre la app (no al girar ni recrear).
            var showSplash by rememberSaveable { mutableStateOf(true) }
            val progress = remember { Animatable(if (showSplash) 0f else 1f) }
            LaunchedEffect(Unit) {
                if (showSplash) {
                    progress.animateTo(1f, tween(durationMillis = 2200))
                    delay(300)
                    showSplash = false
                }
            }
            val appContext = LocalContext.current
            var licensed by remember { mutableStateOf(License.isActivated(appContext)) }
            // 0 = inicio, 1 = pedir licencia, 2 = app
            val screen = if (showSplash) 0 else if (!licensed) 1 else 2
            Crossfade(targetState = screen, animationSpec = tween(350), label = "screen") { which ->
                when (which) {
                    0 -> SplashScreen(progress.value)
                    1 -> LicenseScreen(
                        onActivated = {
                            licensed = true
                            if (EqController.systemWide) EqService.start(appContext)
                        }
                    )
                    else -> MainScreen()
                }
            }
        }
    }
}

/** Nombre del perfil activo, con la marca de "modificado" si cambiaste algo sin guardar. */
private fun profileLabel(): String {
    val name = EqController.activeProfile ?: return tr("Personalizado", "Custom")
    val shown = presetLabel(name)
    return if (EqController.profileModified) shown + tr(" (modificado)", " (modified)") else shown
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    var showHelp by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showPads by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    // Como el ecualizador arranca activado, se pide el permiso de notificaciones al abrir.
    LaunchedEffect(Unit) {
        if (EqController.systemWide &&
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding(),
        contentPadding = PaddingValues(EqSpace.sm),
        verticalArrangement = Arrangement.spacedBy(EqSpace.sm)
    ) {
        item { TopBar(
                onHelp = { showHelp = true },
                onSettings = { showSettings = true },
                onSearch = { showSearch = true },
                onPads = { showPads = true }
            ) }
        item {
            SystemCard(
                onToggle = { on ->
                    EqController.changeSystemWide(on)
                    if (on) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(
                                context, Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        EqService.start(context)
                    } else {
                        EqService.stop(context)
                    }
                }
            )
        }
        item { EqualizerCard() }
        item { EffectsRow() }
        item { VolumeCard() }
        item { StatusRow() }
    }

    if (showHelp) HelpDialog(onClose = { showHelp = false })
    if (showSettings) SettingsDialog(onClose = { showSettings = false })
    if (showSearch) YoutubeSearchDialog(onClose = { showSearch = false })
    if (showPads) PadsDialog(onClose = { showPads = false })
}

// ---------------------------------------------------------------------------
// Pantalla de inicio: la perilla del ícono se enciende mientras carga
// ---------------------------------------------------------------------------

@Composable
fun SplashScreen(progress: Float) {
    val colors = LocalEqColors.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .semantics { contentDescription = tr("Cargando Preamplificador", "Loading Preamplificador") },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(modifier = Modifier.size(190.dp)) {
                val stroke = 7.dp.toPx()
                val d = size.width - stroke
                val topLeft = Offset(stroke / 2f, stroke / 2f)
                val arcSize = Size(d, d)
                // Escala de 270 grados, de abajo a la izquierda hasta abajo a la derecha
                drawArc(
                    color = colors.track,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                if (progress > 0f) {
                    drawArc(
                        color = colors.accent,
                        startAngle = 135f,
                        sweepAngle = 270f * progress,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                // Cuerpo de la perilla con su marca, que gira con la carga
                val c = Offset(size.width / 2f, size.height / 2f)
                val r = size.width * 0.28f
                drawCircle(color = colors.accent, radius = r, center = c)
                val a = Math.toRadians((135f + 270f * progress).toDouble())
                val dx = kotlin.math.cos(a).toFloat()
                val dy = kotlin.math.sin(a).toFloat()
                drawLine(
                    color = colors.onAccent,
                    start = Offset(c.x + dx * r * 0.35f, c.y + dy * r * 0.35f),
                    end = Offset(c.x + dx * r * 0.85f, c.y + dy * r * 0.85f),
                    strokeWidth = 4.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Barra superior
// ---------------------------------------------------------------------------

@Composable
fun TopBar(onHelp: () -> Unit, onSettings: () -> Unit, onSearch: () -> Unit, onPads: () -> Unit) {
    val colors = LocalEqColors.current
    var menuOpen by remember { mutableStateOf(false) }
    var themesOpen by remember { mutableStateOf(false) }
    val modes = listOf(
        tr("Sistema", "System") to ThemeChoice.SYSTEM,
        tr("Claro", "Light") to ThemeChoice.LIGHT,
        tr("Oscuro", "Dark") to ThemeChoice.DARK
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "Preamplificador",
            style = EqType.lg,
            color = colors.text,
            modifier = Modifier.padding(start = EqSpace.sm)
        )
        Box {
            // Tres rayitas discretas
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button) { menuOpen = true }
                    .semantics { contentDescription = tr("Menú", "Menu") },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(20.dp)) {
                    val stroke = 2.dp.toPx()
                    for (k in 0..2) {
                        val y = size.height * (0.2f + 0.3f * k)
                        drawLine(
                            color = colors.textMuted,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = stroke,
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false; themesOpen = false }
            ) {
                Column(
                    modifier = Modifier
                        .width(260.dp)
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    DropdownMenuItem(
                        text = {
                            Text(
                                if (EqController.eqOn) tr("Desactivar ecualizador", "Turn equalizer off")
                                else tr("Activar ecualizador", "Turn equalizer on")
                            )
                        },
                        onClick = {
                            EqController.changeEqOn(!EqController.eqOn)
                            menuOpen = false
                            themesOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("Temas", "Themes")) },
                        trailingIcon = { Text(if (themesOpen) "▴" else "▾", color = colors.textMuted) },
                        onClick = { themesOpen = !themesOpen }
                    )
                    if (themesOpen) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = EqSpace.md),
                            horizontalArrangement = Arrangement.spacedBy(EqSpace.xs)
                        ) {
                            modes.forEach { (label, choice) ->
                                val picked = EqController.theme == choice
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 40.dp)
                                        .clip(RoundedCornerShape(percent = 50))
                                        .background(if (picked) colors.accent else colors.track)
                                        .clickable(role = Role.RadioButton) {
                                            EqController.changeTheme(choice)
                                        }
                                        .semantics { selected = picked },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = EqType.xs,
                                        color = if (picked) colors.onAccent else colors.text
                                    )
                                }
                            }
                        }
                        Palettes.all.forEach { pal ->
                            PaletteRow(
                                palette = pal,
                                picked = EqController.paletteId == pal.id,
                                onPick = { EqController.changePalette(pal.id) }
                            )
                        }
                    }
                    DropdownMenuItem(
                        text = { Text(tr("Ajustes", "Settings")) },
                        onClick = {
                            menuOpen = false
                            themesOpen = false
                            onSettings()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Pads") },
                        onClick = {
                            menuOpen = false
                            themesOpen = false
                            onPads()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("Buscar en YouTube (Brave)", "Search YouTube (Brave)")) },
                        onClick = {
                            menuOpen = false
                            themesOpen = false
                            onSearch()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(tr("Cómo probarlo", "How to test it"), color = colors.textMuted) },
                        onClick = {
                            menuOpen = false
                            themesOpen = false
                            onHelp()
                        }
                    )
                }
            }
        }
    }
}

/** Una fila del selector de temas: muestra los colores y la forma de la tapa de ese tema. */
@Composable
private fun PaletteRow(palette: AppPalette, picked: Boolean, onPick: () -> Unit) {
    val dark = when (EqController.theme) {
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
        ThemeChoice.LIGHT -> false
        ThemeChoice.DARK -> true
    }
    val pc = if (dark) palette.dark else palette.light
    val colors = LocalEqColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable(role = Role.RadioButton, onClick = onPick)
            .semantics { selected = picked }
            .padding(horizontal = EqSpace.md),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(
            modifier = Modifier
                .size(width = 56.dp, height = 28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(pc.bg)
        ) {
            drawBandCap(
                style = palette.cap,
                cx = size.width * 0.3f,
                cy = size.height / 2f,
                held = false,
                fill = pc.accent,
                mark = pc.onAccent,
                ring = pc.bg
            )
            drawCircle(color = pc.surface, radius = 5.dp.toPx(), center = Offset(size.width * 0.62f, size.height / 2f))
            drawCircle(color = pc.text, radius = 3.dp.toPx(), center = Offset(size.width * 0.84f, size.height / 2f))
        }
        Text(
            text = paletteLabel(palette),
            style = EqType.sm,
            color = colors.text,
            modifier = Modifier
                .weight(1f)
                .padding(start = EqSpace.md)
        )
        if (picked) Text(text = "✓", style = EqType.sm, color = colors.accent)
    }
}

// ---------------------------------------------------------------------------
// Servicio: ecualizador en todo el teléfono
// ---------------------------------------------------------------------------

@Composable
fun SystemCard(onToggle: (Boolean) -> Unit) {
    val colors = LocalEqColors.current
    val status = when {
        !EqController.systemWide ->
            tr("Apagado. Enciende el interruptor para aplicar los ajustes a la música del teléfono.", "Off. Turn the switch on to apply your settings to the phone's music.")
        EqController.globalActive ->
            tr("Activo sobre todo el audio del teléfono. Motor: ${engineLabel()}.", "Active on all of the phone's audio. Engine: ${engineLabel()}.")
        else ->
            tr("No se pudo activar el ecualizador en este teléfono.", "The equalizer could not be activated on this phone.")
    }

    EqCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = tr("Preamplificador en todo el teléfono", "Preamplificador on the whole phone"),
                style = EqType.sm,
                color = colors.text,
                modifier = Modifier.weight(1f)
            )
            Switch(
                checked = EqController.systemWide,
                onCheckedChange = onToggle,
                modifier = Modifier.semantics {
                    contentDescription = tr("Preamplificador en todo el teléfono", "Preamplificador on the whole phone")
                }
            )
        }
        Text(
            text = status,
            style = EqType.xs,
            color = colors.textMuted,
            modifier = Modifier.padding(top = EqSpace.xs)
        )
    }
}

// ---------------------------------------------------------------------------
// Ecualizador de 10 bandas, presets y perfiles
// ---------------------------------------------------------------------------

@Composable
fun EqualizerCard() {
    val colors = LocalEqColors.current
    var presetsOpen by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val bands = Presets.bandFreqs.size

    EqCard(padding = EqSpace.md) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = tr("Ecualizador", "Equalizer"),
                style = EqType.sm,
                color = colors.text,
                modifier = Modifier.padding(start = EqSpace.xs)
            )
            Switch(
                checked = EqController.eqOn,
                onCheckedChange = { EqController.changeEqOn(it) },
                modifier = Modifier.semantics { contentDescription = tr("Activar ecualizador", "Turn equalizer on") }
            )
        }

        // Ganancia en dB arriba
        Row(modifier = Modifier.fillMaxWidth()) {
            for (i in 0 until bands) {
                Text(
                    text = dbLabel(EqController.gains.getOrElse(i) { 0f }),
                    style = EqType.xs,
                    color = colors.textMuted,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        BandsGraph(
            gains = EqController.gains,
            enabled = EqController.eqOn,
            onChange = { i, db -> EqController.changeBand(i, db) },
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
        )

        // Frecuencia abajo
        Row(modifier = Modifier.fillMaxWidth()) {
            for (i in 0 until bands) {
                Text(
                    text = Presets.bandLabels[i],
                    style = EqType.xs,
                    color = colors.textMuted,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Selector de presets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = EqSpace.sm),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = tr("Presets", "Presets"),
                style = EqType.sm,
                color = colors.textMuted,
                modifier = Modifier.padding(start = EqSpace.xs)
            )
            Box {
                Row(
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .clickable(role = Role.Button) { presetsOpen = true }
                        .padding(horizontal = EqSpace.sm),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = profileLabel(),
                        style = EqType.sm,
                        color = colors.text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(text = " ▾", style = EqType.sm, color = colors.textMuted)
                }
                DropdownMenu(expanded = presetsOpen, onDismissRequest = { presetsOpen = false }) {
                    Presets.builtIn.forEach { (name, values) ->
                        DropdownMenuItem(
                            text = { Text(presetLabel(name)) },
                            onClick = {
                                EqController.applyPreset(name, values)
                                presetsOpen = false
                            }
                        )
                    }
                    if (EqController.customPresets.isNotEmpty()) {
                        DropdownMenuItem(
                            text = { Text(tr("Mis perfiles", "My profiles")) },
                            onClick = { },
                            enabled = false
                        )
                        EqController.customPresets.forEach { (name, values) ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    EqController.applyPreset(name, values)
                                    presetsOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(EqSpace.sm)
        ) {
            OutlinedButton(
                onClick = {
                    newName = EqController.activeProfile
                        .takeIf { EqController.isCustom(it) } ?: ""
                    showSave = true
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
            ) { Text(text = tr("Guardar", "Save"), maxLines = 1) }
            OutlinedButton(
                onClick = { EqController.activeProfile?.let { EqController.deleteCustomPreset(it) } },
                enabled = EqController.isCustom(EqController.activeProfile),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
            ) { Text(text = tr("Eliminar", "Delete"), maxLines = 1) }
        }
    }

    if (showSave) {
        val cleaned = EqController.cleanName(newName)
        val exists = EqController.customPresets.any { it.first == cleaned }
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text(tr("Guardar perfil", "Save profile")) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    label = { Text(tr("Nombre del perfil", "Profile name")) },
                    supportingText = {
                        if (exists) Text(tr("Ya existe un perfil con ese nombre: se reemplazará.", "A profile with that name already exists: it will be replaced."))
                    }
                )
            },
            confirmButton = {
                TextButton(
                    enabled = cleaned.isNotBlank(),
                    onClick = {
                        EqController.saveCustomPreset(newName)
                        newName = ""
                        showSave = false
                    }
                ) { Text(tr("Guardar", "Save")) }
            },
            dismissButton = {
                TextButton(onClick = { showSave = false }) { Text(tr("Cancelar", "Cancel")) }
            }
        )
    }
}

// ---------------------------------------------------------------------------
// Efectos: graves y loudness, cada uno con su interruptor
// ---------------------------------------------------------------------------

@Composable
fun EffectsRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EqSpace.sm)
    ) {
        EffectKnobCard(
            title = tr("Graves", "Bass"),
            percent = EqController.bassPct,
            on = EqController.bassOn,
            onToggle = { EqController.changeBassOn(it) },
            onPercent = { EqController.changeBassPct(it) },
            modifier = Modifier.weight(1f)
        )
        EffectKnobCard(
            title = "Loudness",
            percent = EqController.loudnessPct,
            on = EqController.loudnessOn,
            onToggle = { EqController.changeLoudnessOn(it) },
            onPercent = { EqController.changeLoudnessPct(it) },
            modifier = Modifier.weight(1f)
        )
    }
}

// ---------------------------------------------------------------------------
// Volumen del teléfono
// ---------------------------------------------------------------------------

@Composable
fun VolumeCard() {
    val context = LocalContext.current
    val colors = LocalEqColors.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember {
        audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    }
    var vol by remember { mutableIntStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC)) }

    // Se vuelve a leer para seguir los botones físicos de volumen.
    LaunchedEffect(Unit) {
        while (true) {
            vol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            delay(500)
        }
    }

    EqCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = tr("Volumen", "Volume"), style = EqType.sm, color = colors.text)
            Text(text = "${vol * 100 / maxVol}%", style = EqType.xs, color = colors.textMuted)
        }
        Slider(
            value = vol.toFloat(),
            onValueChange = { v ->
                val n = v.roundToInt().coerceIn(0, maxVol)
                vol = n
                runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, n, 0) }
            },
            valueRange = 0f..maxVol.toFloat(),
            steps = (maxVol - 1).coerceAtLeast(0),
            modifier = Modifier.semantics { contentDescription = tr("Volumen del teléfono", "Phone volume") }
        )
    }
}

// ---------------------------------------------------------------------------
// Estado: perfil activo
// ---------------------------------------------------------------------------

@Composable
fun StatusRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EqSpace.sm)
    ) {
        PillChip(
            text = profileLabel(),
            modifier = Modifier.fillMaxWidth(),
            highlight = EqController.profileModified
        )
    }
}

// ---------------------------------------------------------------------------
// Ayuda
// ---------------------------------------------------------------------------

@Composable
fun HelpDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Cómo probarlo", "How to test it")) },
        text = {
            Text(
                tr(
                    "1. Activa «Preamplificador en todo el teléfono».\n" +
                        "2. Pon música en Spotify, YouTube Music u otro reproductor.\n" +
                        "3. Sube mucho las bandas graves para notar el cambio.\n\n" +
                        "Se aplica a todo el sonido del teléfono sin importar la app. " +
                        "Si un efecto no se nota, es posible que tu teléfono no lo soporte.",
                    "1. Turn on «Preamplificador on the whole phone».\n" +
                        "2. Play music in Spotify, YouTube Music or another player.\n" +
                        "3. Raise the low bands a lot to hear the change.\n\n" +
                        "It applies to all of the phone's sound, whatever the app. " +
                        "If an effect is not noticeable, your phone may not support it."
                )
            )
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text(tr("Entendido", "Got it")) }
        }
    )
}

// ---------------------------------------------------------------------------
// Ajustes: idioma y frecuencia de los graves
// ---------------------------------------------------------------------------

private fun engineLabel(): String = when (EqController.engineKind) {
    "dp" -> tr("10 bandas reales", "true 10 bands")
    "classic" -> tr("ecualizador del sistema (aproximado a 10 bandas)", "system equalizer (approximated to 10 bands)")
    else -> tr("sin motor activo todavía", "no engine active yet")
}

@Composable
internal fun ChoiceChips(
    options: List<Pair<String, Boolean>>,
    onPick: (Int) -> Unit
) {
    val colors = LocalEqColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(EqSpace.xs)
    ) {
        options.forEachIndexed { index, (label, picked) ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(if (picked) colors.accent else colors.track)
                    .clickable(role = Role.RadioButton) { onPick(index) }
                    .semantics { selected = picked },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    style = EqType.xs,
                    color = if (picked) colors.onAccent else colors.text,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    val colors = LocalEqColors.current
    val langs = listOf(Lang.SYSTEM, Lang.ES, Lang.EN)
    val langNames = listOf(tr("Sistema", "System"), "Español", "English")
    val freqs = listOf(40, 60, 80, 100, 125)

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Ajustes", "Settings")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(EqSpace.sm)) {
                Text(tr("Idioma", "Language"), style = EqType.sm, color = colors.text)
                ChoiceChips(
                    options = langs.mapIndexed { i, l -> langNames[i] to (EqController.lang == l) },
                    onPick = { EqController.changeLang(langs[it]) }
                )
                Text(
                    tr("Frecuencia de los graves", "Bass frequency"),
                    style = EqType.sm,
                    color = colors.text,
                    modifier = Modifier.padding(top = EqSpace.sm)
                )
                ChoiceChips(
                    options = freqs.map { "$it Hz" to (EqController.bassFreq == it) },
                    onPick = { EqController.changeBassFreq(freqs[it]) }
                )
                Text(
                    tr(
                        "Dónde se concentra el refuerzo de graves. Solo con el motor de 10 bandas.",
                        "Where the bass boost is centred. Only with the 10-band engine."
                    ),
                    style = EqType.xs,
                    color = colors.textMuted
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text(tr("Listo", "Done")) }
        }
    )
}

// ---------------------------------------------------------------------------
// Activación: el cliente envía el ID de su teléfono y pega el código que recibe
// ---------------------------------------------------------------------------

@Composable
fun LicenseScreen(onActivated: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalEqColors.current
    val deviceId = remember { License.deviceId(context) }
    var code by remember { mutableStateOf("") }
    var failed by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(EqSpace.lg),
        verticalArrangement = Arrangement.spacedBy(EqSpace.md)
    ) {
        Text(
            text = tr("Activar Preamplificador", "Activate Preamplificador"),
            style = EqType.lg,
            color = colors.text,
            modifier = Modifier.padding(top = EqSpace.lg)
        )
        Text(
            text = tr(
                "Esta app se activa en cada teléfono. Envía el ID de abajo a quien te entregó la app y pega aquí el código que te devuelva.",
                "This app is activated on each phone. Send the ID below to whoever gave you the app and paste the code you get back."
            ),
            style = EqType.base,
            color = colors.textMuted
        )

        EqCard {
            Text(text = tr("ID de este teléfono", "This phone's ID"), style = EqType.xs, color = colors.textMuted)
            Text(
                text = deviceId,
                style = EqType.lg,
                color = colors.text,
                modifier = Modifier.padding(vertical = EqSpace.sm)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(EqSpace.sm)) {
                OutlinedButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("ID", deviceId))
                        copied = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) { Text(if (copied) tr("Copiado", "Copied") else tr("Copiar", "Copy"), maxLines = 1) }
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Preamplificador ID: $deviceId")
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) { Text(tr("Enviar", "Send"), maxLines = 1) }
            }
        }

        OutlinedTextField(
            value = code,
            onValueChange = { code = it; failed = false },
            label = { Text(tr("Código de activación", "Activation code")) },
            isError = failed,
            supportingText = {
                if (failed) Text(tr("Código no válido para este teléfono.", "This code is not valid for this phone."))
            },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                if (License.activate(context, code)) onActivated() else failed = true
            },
            enabled = code.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
        ) { Text(tr("Activar", "Activate")) }
    }
}

// ---------------------------------------------------------------------------
// Buscar en YouTube con Brave: la app solo abre el navegador; no se conecta a internet
// ---------------------------------------------------------------------------

private const val BRAVE_PACKAGE = "com.brave.browser"

private fun youtubeUrl(query: String): String =
    if (query.isBlank()) "https://m.youtube.com/"
    else "https://m.youtube.com/results?search_query=" + Uri.encode(query.trim())

/** Abre la dirección en Brave. Devuelve false si Brave no está instalado. */
private fun openInBrave(context: Context, query: String): Boolean {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl(query))).setPackage(BRAVE_PACKAGE)
    return try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}

private fun tryStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        // Sin aplicación que lo abra: no se hace nada.
    }
}

@Composable
fun YoutubeSearchDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalEqColors.current
    var query by remember { mutableStateOf("") }
    var missing by remember { mutableStateOf(false) }

    if (!missing) {
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(tr("Buscar en YouTube", "Search YouTube")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(EqSpace.sm)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        label = { Text(tr("Canción o lista", "Song or playlist")) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = tr(
                            "Se abre en Brave, que bloquea los anuncios. Esta app no ve ni guarda lo que buscas.",
                            "Opens in Brave, which blocks ads. This app does not see or store what you search."
                        ),
                        style = EqType.xs,
                        color = colors.textMuted
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (openInBrave(context, query)) onClose() else missing = true
                }) { Text(tr("Abrir en Brave", "Open in Brave")) }
            },
            dismissButton = {
                TextButton(onClick = onClose) { Text(tr("Cancelar", "Cancel")) }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(tr("Brave no está instalado", "Brave is not installed")) },
            text = {
                Text(
                    tr(
                        "Instala Brave para ver YouTube sin anuncios. Si prefieres, puedes abrir la búsqueda en tu navegador normal, pero ahí los anuncios sí aparecerán.",
                        "Install Brave to watch YouTube without ads. You can also open the search in your regular browser, but ads will show there."
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    tryStart(
                        context,
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$BRAVE_PACKAGE"))
                    )
                    onClose()
                }) { Text(tr("Instalar Brave", "Install Brave")) }
            },
            dismissButton = {
                TextButton(onClick = {
                    tryStart(context, Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl(query))))
                    onClose()
                }) { Text(tr("Abrir en mi navegador", "Open in my browser")) }
            }
        )
    }
}
