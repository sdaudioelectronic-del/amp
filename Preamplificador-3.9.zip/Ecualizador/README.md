# Ecualizador (Android) - versión 2

Ecualizador de 10 bandas que se aplica al audio de otras apps (Spotify, YouTube Music,
etc.). No tiene reproductor propio, ni anuncios, ni compras.

## Qué incluye

- Ecualizador de 10 bandas (31 Hz a 16 kHz, de -12 a +12 dB) con sliders verticales.
- Ganancia / preamp, graves (Bass Boost) y sonido envolvente (Virtualizer).
- 10 presets de fábrica y presets propios (guardar con nombre y eliminar).
- Dos modos de conexión:
  - **Global:** aplica el efecto a toda la salida de audio del teléfono.
  - **Por reproductor:** se conecta a las apps que avisan su sesión de audio.
- Servicio en segundo plano con notificación (necesario para que siga activo).
- Tema claro, oscuro o automático.

## Cómo actualizar el repositorio de GitHub

1. Descomprime el ZIP.
2. Entra a tu repositorio, a la carpeta donde ya está la carpeta `app`
   (la misma donde subiste el proyecto la primera vez).
3. **Add file > Upload files** y arrastra las carpetas y archivos del ZIP
   (los que ya existen se reemplazan, los nuevos se agregan).
4. **Commit changes**. La compilación arranca sola en la pestaña **Actions**.
5. Al terminar, el APK nuevo está en **Releases** (versión más reciente).

## Cómo probarlo en el teléfono

1. Instala el APK nuevo (sobre el anterior; se actualiza).
2. Abre la app y activa **Ecualizador en todo el teléfono**. Acepta el permiso de notificaciones.
3. Abre Spotify, YouTube Music u otro reproductor y pon música.
4. Sube mucho los graves (las bandas de la izquierda) para notar el cambio.
5. Si no se nota, cambia a **Por reproductor** y reinicia la canción.

## Limitaciones conocidas

- El efecto sobre otras apps depende del teléfono y de su versión de Android. Algunos
  fabricantes bloquean el modo global, y algunas apps no avisan su sesión de audio.
- La pantalla "Motor" te dice qué sistema se está usando. Si dice "sin motor activo",
  el teléfono no permite ese efecto.
- Sin reproductor propio, el reverb se quitó. Aplicarlo a otras apps necesita otro enfoque.
- Este APK es de tipo *debug*: se instala y reparte sin problema, pero no sirve para Google Play.
