package com.ecualizador.app

import java.util.Locale

/** Idioma de la app. "Sistema" usa español si el teléfono está en español y, si no, inglés. */
enum class Lang { SYSTEM, ES, EN }

val isEnglish: Boolean
    get() = when (EqController.lang) {
        Lang.EN -> true
        Lang.ES -> false
        Lang.SYSTEM -> Locale.getDefault().language != "es"
    }

/** Devuelve el texto en el idioma activo. Leer EqController.lang hace que la pantalla se redibuje al cambiarlo. */
fun tr(es: String, en: String): String = if (isEnglish) en else es

private val presetNamesEn = mapOf(
    "Plano" to "Neutral",
    "Clásica" to "Classical",
    "Graves" to "Bass",
    "Agudos" to "Treble",
    "Voz" to "Vocal"
)

/** Nombre mostrado de un preset de fábrica. El nombre guardado no cambia. */
fun presetLabel(name: String): String = if (isEnglish) presetNamesEn[name] ?: name else name

private val paletteNamesEn = mapOf(
    "amber" to "Amber", "ocean" to "Ocean", "neon" to "Neon",
    "rose" to "Rose", "forest" to "Forest", "violet" to "Violet"
)

/** Nombre mostrado de un tema visual. */
fun paletteLabel(p: AppPalette): String = if (isEnglish) paletteNamesEn[p.id] ?: p.name else p.name
