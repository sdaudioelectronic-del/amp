package com.ecualizador.app

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------
// Tokens de diseño (replica/design/tokens.json y tokens-light.json).
// Los nombres de rol son fijos; los valores los cambia replica-brand.
// ---------------------------------------------------------------------------

@Immutable
data class EqColors(
    val bg: Color,
    val surface: Color,
    val border: Color,
    val borderInput: Color,
    val text: Color,
    val textMuted: Color,
    val accent: Color,
    val onAccent: Color,
    val danger: Color,
    val success: Color,
    val track: Color,
    val thumb: Color
)

val DarkEqColors = EqColors(
    bg = Color(0xFF14110F),
    surface = Color(0xFF1F1B18),
    border = Color(0xFF332E29),
    borderInput = Color(0xFF9A8F83),
    text = Color(0xFFF4EFE9),
    textMuted = Color(0xFFB8AEA2),
    accent = Color(0xFFF2A93B),
    onAccent = Color(0xFF2A1800),
    danger = Color(0xFFFF8A80),
    success = Color(0xFF7DDC9E),
    track = Color(0xFF3B352F),
    thumb = Color(0xFFCFC5B8)
)

val LightEqColors = EqColors(
    bg = Color(0xFFF7F3EE),
    surface = Color(0xFFFFFFFF),
    border = Color(0xFFE0D8CE),
    borderInput = Color(0xFF7A6F63),
    text = Color(0xFF1C1814),
    textMuted = Color(0xFF5E554B),
    accent = Color(0xFF9A5A00),
    onAccent = Color(0xFFFFFFFF),
    danger = Color(0xFFB3261E),
    success = Color(0xFF1B7A43),
    track = Color(0xFFD6CCBF),
    thumb = Color(0xFF5E554B)
)

val LocalEqColors = staticCompositionLocalOf { DarkEqColors }

/** Forma de las tapas de las bandas del tema activo. */
val LocalCapStyle = staticCompositionLocalOf { CapStyle.FADER }

/** Espaciado: base de 8 dp. */
object EqSpace {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
}

object EqRadius {
    val md = 12.dp
}

/** Escala de texto: 12, 14, 16 y 20. */
object EqType {
    val xs = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Normal)
    val sm = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
    val base = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal)
    val lg = TextStyle(fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun EqTheme(dark: Boolean, palette: AppPalette, content: @Composable () -> Unit) {
    val c = if (dark) palette.dark else palette.light
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent,
            onPrimary = c.onAccent,
            background = c.bg,
            onBackground = c.text,
            surface = c.surface,
            onSurface = c.text,
            surfaceVariant = c.track,
            onSurfaceVariant = c.textMuted,
            secondaryContainer = c.track,
            onSecondaryContainer = c.text,
            outline = c.borderInput,
            outlineVariant = c.border,
            error = c.danger
        )
    } else {
        lightColorScheme(
            primary = c.accent,
            onPrimary = c.onAccent,
            background = c.bg,
            onBackground = c.text,
            surface = c.surface,
            onSurface = c.text,
            surfaceVariant = c.track,
            onSurfaceVariant = c.textMuted,
            secondaryContainer = c.track,
            onSecondaryContainer = c.text,
            outline = c.borderInput,
            outlineVariant = c.border,
            error = c.danger
        )
    }
    CompositionLocalProvider(LocalEqColors provides c, LocalCapStyle provides palette.cap) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Tarjeta plana: se separa del fondo por tono, sin sombra. */
@Composable
fun EqCard(
    modifier: Modifier = Modifier,
    padding: androidx.compose.ui.unit.Dp = EqSpace.lg,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalEqColors.current
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(EqRadius.md),
        colors = CardDefaults.cardColors(containerColor = c.surface)
    ) {
        Column(modifier = Modifier.padding(padding), content = content)
    }
}
