package com.ecualizador.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Mode { GLOBAL, SESSIONS }

enum class ThemeChoice { SYSTEM, LIGHT, DARK }

/**
 * Cerebro del ecualizador: guarda los ajustes (visibles en la interfaz) y decide
 * a qué sesiones de audio se conectan los efectos.
 *
 *  - Modo GLOBAL: un solo conjunto de efectos sobre toda la salida de audio (sesión 0).
 *  - Modo SESSIONS: un conjunto de efectos por cada reproductor que avise su sesión.
 *
 * Cada efecto (graves y loudness) tiene su propio interruptor y su
 * propio porcentaje, y el ecualizador de bandas tiene el suyo.
 *
 * Todo se usa desde el hilo principal.
 */
object EqController {

    private var prefs: SharedPreferences? = null

    // ----- Estado observable por la interfaz -----
    val gains = mutableStateListOf<Float>()
    var eqOn by mutableStateOf(true)

    var loudnessOn by mutableStateOf(false)
    var loudnessPct by mutableIntStateOf(30)
    var bassOn by mutableStateOf(false)
    var bassPct by mutableIntStateOf(50)

    var mode by mutableStateOf(Mode.GLOBAL)
    var theme by mutableStateOf(ThemeChoice.SYSTEM)

    /** Tema visual elegido (colores y forma de las tapas). Solo diseño. */
    var paletteId by mutableStateOf("amber")

    var lang by mutableStateOf(Lang.SYSTEM)

    /** Frecuencia central del refuerzo de graves, en Hz (solo motor de 10 bandas). */
    var bassFreq by mutableIntStateOf(80)
    var systemWide by mutableStateOf(true)

    /** Nombre del perfil (de fábrica o propio) que se está usando, o null si ninguno. */
    var activeProfile by mutableStateOf<String?>(null)

    /** true si moviste las bandas después de cargar el perfil y no lo has guardado. */
    var profileModified by mutableStateOf(false)

    val customPresets = mutableStateListOf<Pair<String, List<Float>>>()

    // ----- Estado informativo -----
    var engineKind by mutableStateOf("none")
    var globalActive by mutableStateOf(false)
    var activeSessions by mutableIntStateOf(0)

    // ----- Efectos conectados -----
    private var globalChain: EffectChain? = null
    private val sessionChains = HashMap<Int, EffectChain>()
    private var running = false

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences("eq_prefs", Context.MODE_PRIVATE)
        load()
    }

    // ---------------------------------------------------------------------
    // Persistencia
    // ---------------------------------------------------------------------

    private fun load() {
        val p = prefs ?: return
        val saved = p.getString("gains", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
        gains.clear()
        if (saved != null && saved.size == Presets.bandFreqs.size) {
            gains.addAll(saved)
        } else {
            repeat(Presets.bandFreqs.size) { gains.add(0f) }
        }
        eqOn = p.getBoolean("eqOn", true)
        loudnessOn = p.getBoolean("loudnessOn", false)
        loudnessPct = p.getInt("loudnessPct", 30).coerceIn(0, 100)
        bassOn = p.getBoolean("bassOn", false)
        bassPct = p.getInt("bassPct", 50).coerceIn(0, 100)
        mode = Mode.GLOBAL
        theme = runCatching { ThemeChoice.valueOf(p.getString("theme", "SYSTEM") ?: "SYSTEM") }
            .getOrDefault(ThemeChoice.SYSTEM)
        paletteId = Palettes.byId(p.getString("palette", "amber")).id
        lang = runCatching { Lang.valueOf(p.getString("lang", "SYSTEM") ?: "SYSTEM") }.getOrDefault(Lang.SYSTEM)
        bassFreq = p.getInt("bassFreq", 80).coerceIn(40, 125)
        systemWide = p.getBoolean("systemWide", true)
        activeProfile = p.getString("profile", null)
        profileModified = p.getBoolean("profileModified", false)

        customPresets.clear()
        (p.getString("custom", "") ?: "").split(";").filter { it.contains("|") }.forEach { line ->
            val parts = line.split("|")
            if (parts.size == 2) {
                val values = parts[1].split(",").mapNotNull { it.toFloatOrNull() }
                if (values.size == Presets.bandFreqs.size) customPresets.add(parts[0] to values)
            }
        }
    }

    private fun save() {
        val p = prefs ?: return
        p.edit()
            .putString("gains", gains.joinToString(","))
            .putBoolean("eqOn", eqOn)
            .putBoolean("loudnessOn", loudnessOn)
            .putInt("loudnessPct", loudnessPct)
            .putBoolean("bassOn", bassOn)
            .putInt("bassPct", bassPct)
            .putString("mode", mode.name)
            .putString("theme", theme.name)
            .putString("palette", paletteId)
            .putString("lang", lang.name)
            .putInt("bassFreq", bassFreq)
            .putBoolean("systemWide", systemWide)
            .putString("profile", activeProfile)
            .putBoolean("profileModified", profileModified)
            .putString(
                "custom",
                customPresets.joinToString(";") { it.first + "|" + it.second.joinToString(",") }
            )
            .apply()
    }

    // ---------------------------------------------------------------------
    // Efectos de audio
    // ---------------------------------------------------------------------

    private fun snapshot() = EqSettings(
        eqEnabled = eqOn,
        gains = gains.toList(),
        // Loudness: 0 % a 100 % equivale a 0 dB a +12 dB.
        preampDb = if (loudnessOn) loudnessPct * 0.12f else 0f,
        // Graves: 0 % a 100 % equivale a 0 a 1000.
        bass = if (bassOn) bassPct * 10 else 0,
        bassFreq = bassFreq
    )

    private fun applyAll() {
        val s = snapshot()
        globalChain?.push(s)
        sessionChains.values.forEach { it.push(s) }
        save()
    }

    /** El servicio llama a esto al arrancar. */
    fun startEngine() {
        running = true
        rebuild()
    }

    /** El servicio llama a esto al detenerse. */
    fun stopEngine() {
        running = false
        rebuild()
    }

    /** Reconstruye los efectos según el modo y si el servicio está activo. */
    fun rebuild() {
        globalChain?.release()
        globalChain = null
        sessionChains.values.forEach { it.release() }
        sessionChains.clear()

        if (running && mode == Mode.GLOBAL) {
            val chain = EffectChain(0)
            if (chain.hasEq) {
                globalChain = chain
                chain.push(snapshot())
            } else {
                chain.release()
            }
        }
        updateStatus()
    }

    /** Otra app avisó que abrió una sesión de audio (modo SESSIONS). */
    fun onSessionOpen(id: Int) {
        if (!running || mode != Mode.SESSIONS || id <= 0) return
        sessionChains.remove(id)?.release()
        val chain = EffectChain(id)
        if (chain.available) {
            sessionChains[id] = chain
            chain.push(snapshot())
        } else {
            chain.release()
        }
        updateStatus()
    }

    fun onSessionClose(id: Int) {
        sessionChains.remove(id)?.release()
        updateStatus()
    }

    private fun updateStatus() {
        globalActive = globalChain != null
        activeSessions = sessionChains.size
        val chains = listOfNotNull(globalChain) + sessionChains.values
        engineKind = when {
            chains.any { it.engine == "dp" } -> "dp"
            chains.any { it.engine == "classic" } -> "classic"
            else -> "none"
        }
    }

    // ---------------------------------------------------------------------
    // Cambios hechos desde la interfaz
    // ---------------------------------------------------------------------

    fun changeBand(index: Int, db: Float) {
        if (index !in gains.indices) return
        val v = db.coerceIn(Presets.MIN_DB, Presets.MAX_DB)
        if (gains[index] == v) return
        gains[index] = v
        if (activeProfile != null) profileModified = true
        applyAll()
    }

    fun changeEqOn(value: Boolean) {
        eqOn = value
        applyAll()
    }

    fun changeLoudnessOn(value: Boolean) {
        loudnessOn = value
        applyAll()
    }

    fun changeLoudnessPct(value: Int) {
        loudnessPct = value.coerceIn(0, 100)
        applyAll()
    }

    fun changeBassOn(value: Boolean) {
        bassOn = value
        applyAll()
    }

    fun changeBassPct(value: Int) {
        bassPct = value.coerceIn(0, 100)
        applyAll()
    }

    fun changeMode(newMode: Mode) {
        if (mode == newMode) return
        mode = newMode
        save()
        rebuild()
    }

    fun changeTheme(newTheme: ThemeChoice) {
        theme = newTheme
        save()
    }

    fun changeLang(value: Lang) {
        lang = value
        save()
    }

    fun changeBassFreq(hz: Int) {
        bassFreq = hz.coerceIn(40, 125)
        applyAll()
    }

    fun changePalette(id: String) {
        paletteId = Palettes.byId(id).id
        save()
    }

    fun changeSystemWide(value: Boolean) {
        systemWide = value
        save()
    }

    fun applyPreset(name: String, values: List<Float>) {
        for (i in values.indices) {
            if (i in gains.indices) gains[i] = values[i]
        }
        activeProfile = name
        profileModified = false
        applyAll()
    }

    /** Guarda las bandas actuales con ese nombre. Si ya existía, lo reemplaza. */
    fun saveCustomPreset(name: String) {
        val clean = cleanName(name)
        if (clean.isBlank()) return
        customPresets.removeAll { it.first == clean }
        customPresets.add(clean to gains.toList())
        activeProfile = clean
        profileModified = false
        save()
    }

    fun deleteCustomPreset(name: String) {
        customPresets.removeAll { it.first == name }
        if (activeProfile == name) {
            activeProfile = null
            profileModified = false
        }
        save()
    }

    /** Los separadores del guardado no pueden ir en el nombre. */
    fun cleanName(name: String): String =
        name.trim().replace(Regex("[;|,]"), " ").take(24).trim()

    fun isCustom(name: String?): Boolean = name != null && customPresets.any { it.first == name }
}
