package com.ecualizador.app

import android.content.Context
import android.provider.Settings
import android.util.Base64
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Licencia por teléfono, sin internet y sin fecha de vencimiento.
 *
 * Cada teléfono muestra un ID. El dueño de la app firma ese ID con su llave privada
 * (que NUNCA está en la app) y entrega el código de activación. La app solo lleva la
 * llave pública, que sirve para comprobar firmas pero no para crearlas.
 */
object License {

    private const val PUBLIC_KEY = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0VSiNCavCr4XuHq/bU1zEj9OJyJM2ujyBkgEcDGscpCf5BpJIRXoVYky/CJC5QiXw1pELzj8PIK1H6nBa+v1yg=="
    private const val PREFIX = "PREAMP1|"
    private const val PREFS = "license_prefs"
    private const val KEY_CODE = "code"

    /** ID corto y estable de este teléfono para esta app, tipo "A1B2-C3D4-E5F6". */
    fun deviceId(context: Context): String {
        val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "desconocido"
        val hash = MessageDigest.getInstance("SHA-256").digest(("preamp|" + raw).toByteArray())
        val hex = hash.take(6).joinToString("") { "%02X".format(it) }
        return hex.chunked(4).joinToString("-")
    }

    fun isActivated(context: Context): Boolean {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CODE, null)
        return saved != null && verify(deviceId(context), saved)
    }

    /** Guarda el código si es válido para este teléfono. */
    fun activate(context: Context, code: String): Boolean {
        val clean = code.filterNot { it.isWhitespace() }
        if (!verify(deviceId(context), clean)) return false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CODE, clean).apply()
        return true
    }

    private fun verify(deviceId: String, code: String): Boolean = runCatching {
        val raw = Base64.decode(code, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        if (raw.size != 64) return false
        val key = KeyFactory.getInstance("EC")
            .generatePublic(X509EncodedKeySpec(Base64.decode(PUBLIC_KEY, Base64.DEFAULT)))
        val sig = Signature.getInstance("SHA256withECDSA")
        sig.initVerify(key)
        sig.update((PREFIX + deviceId).toByteArray())
        sig.verify(rawToDer(raw))
    }.getOrDefault(false)

    /** La firma viene como r||s (64 bytes); Android la espera en formato DER. */
    private fun rawToDer(raw: ByteArray): ByteArray {
        fun part(b: ByteArray): ByteArray {
            var i = 0
            while (i < b.size - 1 && b[i] == 0.toByte()) i++
            var out = b.copyOfRange(i, b.size)
            if (out[0] < 0) out = byteArrayOf(0) + out
            return byteArrayOf(0x02, out.size.toByte()) + out
        }
        val r = part(raw.copyOfRange(0, 32))
        val s = part(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (r.size + s.size).toByte()) + r + s
    }
}
