package com.ecualizador.app

import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.sqrt

/** Valores actuales del ecualizador, listos para enviarse a los efectos de audio. */
data class EqSettings(
    /** Solo las bandas del ecualizador. Los efectos se apagan por su cuenta. */
    val eqEnabled: Boolean,
    val gains: List<Float>,
    /** Ganancia (loudness) en dB; 0 = apagada. */
    val preampDb: Float,
    /** Intensidad de graves 0 a 1000; 0 = apagado. */
    val bass: Int,
    /** Frecuencia central del refuerzo de graves en Hz. */
    val bassFreq: Int = 80
)

/**
 * Conjunto de efectos de audio conectados a UNA sesión de audio.
 * sessionId = 0 significa "toda la salida del teléfono" (modo global).
 *
 * Motor de ecualizador, en orden de preferencia:
 *  1. DynamicsProcessing (Android 9+): 10 bandas reales.
 *  2. Equalizer clásico del sistema: bandas del teléfono, aproximadas a nuestras 10.
 */
class EffectChain(val sessionId: Int) {

    private var dp: DynamicsProcessing? = null
    private var classicEq: Equalizer? = null
    private var bass: BassBoost? = null
    private var loud: LoudnessEnhancer? = null

    private val bandCount = Presets.bandFreqs.size

    /** Frecuencia superior de cada banda (punto medio geométrico entre centros). */
    private val edges = FloatArray(bandCount) { i ->
        if (i == bandCount - 1) {
            20000f
        } else {
            sqrt(Presets.bandFreqs[i].toFloat() * Presets.bandFreqs[i + 1].toFloat())
        }
    }

    /** "dp", "classic" o "none". */
    var engine: String = "none"
        private set

    val hasEq: Boolean get() = engine != "none"
    val available: Boolean get() = hasEq || bass != null || loud != null

    init {
        dp = createDynamicsProcessing()
        if (dp != null) {
            engine = "dp"
        } else {
            classicEq = runCatching { Equalizer(0, sessionId) }.getOrNull()
            if (classicEq != null) engine = "classic"
        }
        // Con el motor de 10 bandas, los graves se hacen subiendo las bandas bajas
        // y el loudness con la ganancia de entrada: no se usan BassBoost ni
        // LoudnessEnhancer, que en algunos teléfonos silencian todo el audio.
        if (dp == null) {
            bass = runCatching { BassBoost(0, sessionId) }.getOrNull()
            loud = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        }
    }

    // Últimos valores enviados: se evita repetir llamadas al sistema de audio mientras
    // arrastras la perilla, porque cambiar el efecto muchas veces por segundo puede
    // dejarlo en silencio en algunos teléfonos.
    private var lastBassStrength = -1
    private var lastBassOn = false

    /**
     * Subida de graves (en dB) para la banda i. El refuerzo se centra en la frecuencia elegida
     * y baja hacia las bandas vecinas. La banda más cercana recibe el 100 % (hasta 8 dB).
     */
    private fun bassBoostDb(i: Int, bass: Int, freq: Int): Float {
        fun w(band: Int): Float {
            val octaves = abs(ln(Presets.bandFreqs[band].toFloat() / freq.toFloat()) / ln(2f))
            return (1f - octaves / 1.5f).coerceAtLeast(0f)
        }
        val peak = (0 until bandCount).maxOf { w(it) }.coerceAtLeast(0.01f)
        return bass / 1000f * 8f * (w(i) / peak)
    }

    private fun createDynamicsProcessing(): DynamicsProcessing? {
        return try {
            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,
                true, bandCount,
                false, 0,
                false, 0,
                true
            ).build()
            val d = DynamicsProcessing(0, sessionId, config)
            // Limitador suave para evitar distorsión cuando se sube la ganancia.
            d.setLimiterAllChannelsTo(
                DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f)
            )
            d
        } catch (e: Throwable) {
            null
        }
    }

    private fun nearestBand(hz: Float): Int {
        var best = 0
        var bestDistance = Float.MAX_VALUE
        for (i in Presets.bandFreqs.indices) {
            val distance = abs(ln(hz / Presets.bandFreqs[i]))
            if (distance < bestDistance) {
                bestDistance = distance
                best = i
            }
        }
        return best
    }

    /** Envía los valores actuales a todos los efectos de esta sesión. */
    fun push(s: EqSettings) {
        // Con el ecualizador apagado las bandas quedan planas, sin tocar los demás efectos.
        val g = if (s.eqEnabled) s.gains else List(bandCount) { 0f }

        dp?.let { d ->
            runCatching {
                val eq = DynamicsProcessing.Eq(true, true, bandCount)
                for (i in 0 until bandCount) {
                    val db = (g.getOrElse(i) { 0f } + bassBoostDb(i, s.bass, s.bassFreq)).coerceIn(-20f, 20f)
                    eq.setBand(i, DynamicsProcessing.EqBand(true, edges[i], db))
                }
                d.setPreEqAllChannelsTo(eq)
                d.setInputGainAllChannelsTo(s.preampDb)
                d.setEnabled(s.eqEnabled || s.preampDb > 0f || s.bass > 0)
            }
        }

        classicEq?.let { e ->
            runCatching {
                val range = e.bandLevelRange
                val minLevel = range[0].toInt()
                val maxLevel = range[1].toInt()
                for (b in 0 until e.numberOfBands.toInt()) {
                    val centerHz = e.getCenterFreq(b.toShort()) / 1000f
                    val idx = nearestBand(centerHz)
                    val level = (g.getOrElse(idx) { 0f } * 100f).toInt()
                        .coerceIn(minLevel, maxLevel)
                    e.setBandLevel(b.toShort(), level.toShort())
                }
                e.setEnabled(s.eqEnabled)
            }
        }

        bass?.let { b ->
            runCatching {
                val on = s.bass > 0
                val strength = (s.bass / 50) * 50
                if (on && b.strengthSupported && strength != lastBassStrength) {
                    b.setStrength(strength.toShort())
                    lastBassStrength = strength
                }
                if (on != lastBassOn) {
                    b.setEnabled(on)
                    lastBassOn = on
                }
            }
        }

        loud?.let { l ->
            runCatching {
                l.setTargetGain((s.preampDb.coerceAtLeast(0f) * 100f).toInt())
                l.setEnabled(s.preampDb > 0f)
            }
        }
    }

    fun release() {
        runCatching { dp?.release() }
        runCatching { classicEq?.release() }
        runCatching { bass?.release() }
        runCatching { loud?.release() }
        dp = null
        classicEq = null
        bass = null
        loud = null
        engine = "none"
    }
}
