package com.ecualizador.app

/** Datos fijos del ecualizador: frecuencias de las 10 bandas y presets de fábrica. */
object Presets {

    val bandFreqs = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val bandLabels = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    const val MIN_DB = -12f
    const val MAX_DB = 12f

    val builtIn: List<Pair<String, List<Float>>> = listOf(
        "Plano" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Rock" to listOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f),
        "Pop" to listOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
        "Jazz" to listOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f),
        "Clásica" to listOf(4f, 3f, 2f, 1f, -1f, -1f, 0f, 2f, 3f, 4f),
        "Dance" to listOf(6f, 5f, 3f, 0f, 0f, -2f, -3f, -3f, 0f, 0f),
        "Hip Hop" to listOf(5f, 4f, 1f, 3f, -1f, -1f, 1f, -1f, 2f, 3f),
        "Graves" to listOf(7f, 6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f),
        "Agudos" to listOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 7f),
        "Voz" to listOf(-2f, -3f, -2f, 1f, 4f, 4f, 3f, 1f, 0f, -1f)
    )
}
