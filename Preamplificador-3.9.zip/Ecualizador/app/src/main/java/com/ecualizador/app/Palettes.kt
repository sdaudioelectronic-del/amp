package com.ecualizador.app

import androidx.compose.ui.graphics.Color

// Temas visuales: cada uno cambia los colores y la forma de las tapas de las bandas.
// Solo son diseño; no tocan el sonido.

enum class CapStyle { FADER, RING, PILL, DIAMOND }

class AppPalette(
    val id: String,
    val name: String,
    val cap: CapStyle,
    val dark: EqColors,
    val light: EqColors
)

private fun c(hex: String) = Color(0xFF000000L or hex.toLong(16))

private fun colors(v: String, danger: String, success: String): EqColors {
    val p = v.split(" ")
    return EqColors(
        bg = c(p[0]), surface = c(p[1]), border = c(p[2]), borderInput = c(p[3]),
        text = c(p[4]), textMuted = c(p[5]), accent = c(p[6]), onAccent = c(p[7]),
        danger = c(danger), success = c(success), track = c(p[8]), thumb = c(p[9])
    )
}

object Palettes {
    val all: List<AppPalette> = listOf(
        AppPalette(
            id = "amber", name = "Ámbar", cap = CapStyle.FADER,
            dark = colors("14110F 1F1B18 332E29 9A8F83 F4EFE9 B8AEA2 F2A93B 2A1800 3B352F CFC5B8", "FF8A80", "7DDC9E"),
            light = colors("F7F3EE FFFFFF E0D8CE 7A6F63 1C1814 5E554B 9A5A00 FFFFFF D6CCBF 5E554B", "B3261E", "1B7A43")
        ),
        AppPalette(
            id = "ocean", name = "Océano", cap = CapStyle.RING,
            dark = colors("0E1418 151D23 24313A 8497A3 E8F0F4 A5B5BF 4FC3F7 00212E 2B3943 BFCCD4", "FF8A80", "7DDC9E"),
            light = colors("F1F6F9 FFFFFF D3DEE5 62747F 12191D 4A5963 0B6A8F FFFFFF CBD7DF 4A5963", "B3261E", "1B7A43")
        ),
        AppPalette(
            id = "neon", name = "Neón", cap = CapStyle.DIAMOND,
            dark = colors("0D0D14 16161F 2A2A38 8E8EA3 F0F0F7 AEAEC2 B6FF3B 1A2600 30303F C9C9D8", "FF8A80", "7DDC9E"),
            light = colors("F4F4F8 FFFFFF DCDCE6 6B6B80 16161D 53536A 4B7A00 FFFFFF D2D2DE 53536A", "B3261E", "1B7A43")
        ),
        AppPalette(
            id = "rose", name = "Rosa", cap = CapStyle.PILL,
            dark = colors("160F14 20171D 33252E 9C8591 F7EEF2 BFA9B5 FF7AC3 2E0018 3E2F38 D6C3CD", "FF8A80", "7DDC9E"),
            light = colors("FBF3F6 FFFFFF EBD8E0 80626F 1F1419 63505A B3125F FFFFFF E2CDD6 63505A", "B3261E", "1B7A43")
        ),
        AppPalette(
            id = "forest", name = "Bosque", cap = CapStyle.RING,
            dark = colors("0F1511 161E19 25322A 87A08F EAF3EC A6BAAB 7BD88F 05200E 2C3B32 C1D2C6", "FF8A80", "7DDC9E"),
            light = colors("F2F7F3 FFFFFF D6E2D9 5F7667 121A15 4A5B50 1B6B3A FFFFFF CBD9CF 4A5B50", "B3261E", "1B7A43")
        ),
        AppPalette(
            id = "violet", name = "Violeta", cap = CapStyle.DIAMOND,
            dark = colors("12101A 1A1724 2B2639 928BA8 EFEDF7 B0AAC4 B79CFF 1E0E4D 34304A CAC5DA", "FF8A80", "7DDC9E"),
            light = colors("F6F4FB FFFFFF DDD8EC 6F6788 17141F 574F6E 5A3FC0 FFFFFF D6D0E8 574F6E", "B3261E", "1B7A43")
        )
    )

    fun byId(id: String?): AppPalette = all.firstOrNull { it.id == id } ?: all[0]
}
